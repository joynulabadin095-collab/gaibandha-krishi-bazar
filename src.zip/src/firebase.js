// ─────────────────────────────────────────────────────────────
// Firebase Configuration
// ─────────────────────────────────────────────────────────────
// ১. https://console.firebase.google.com এ যাও
// ২. "Add project" → প্রজেক্ট তৈরি করো
// ৩. Project settings → "Add app" → Web (</>)
// ৪. নিচের firebaseConfig-এ তোমার values বসাও
// ─────────────────────────────────────────────────────────────

import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
