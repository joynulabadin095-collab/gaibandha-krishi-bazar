import { useState, useEffect } from "react";
import {
  collection, addDoc, getDocs, doc, updateDoc, deleteDoc,
  query, orderBy, onSnapshot
} from "firebase/firestore";
import { db } from "./firebase";

// ─── Constants ───────────────────────────────────────────────
const SELLER_PASS = "krishi2026";

const CATEGORIES = [
  { id: "vegetables", bn: "সবজি",       en: "Vegetables",  icon: "🥬" },
  { id: "fruits",     bn: "ফল",          en: "Fruits",       icon: "🍋" },
  { id: "grains",     bn: "ধান/চাল/গম", en: "Grains",       icon: "🌾" },
  { id: "fish",       bn: "মাছ",         en: "Fish",         icon: "🐟" },
  { id: "dairy",      bn: "দুধ/ডিম",     en: "Dairy & Eggs", icon: "🥚" },
  { id: "spices",     bn: "মশলা",        en: "Spices",       icon: "🌶️" },
  { id: "other",      bn: "অন্যান্য",    en: "Other",        icon: "🌿" },
];

const UPAZILAS = [
  "গাইবান্ধা সদর","সুন্দরগঞ্জ","সাঘাটা",
  "ফুলছড়ি","গোবিন্দগঞ্জ","পলাশবাড়ী","সাদুল্লাপুর"
];

const STATUS = {
  pending:   { bn: "নতুন অর্ডার",     en: "New Order",  color: "#f59e0b", bg: "#fef3c7" },
  confirmed: { bn: "নিশ্চিত",         en: "Confirmed",  color: "#2d8a45", bg: "#dcfce7" },
  delivered: { bn: "ডেলিভারি হয়েছে", en: "Delivered",  color: "#1d4ed8", bg: "#dbeafe" },
  cancelled: { bn: "বাতিল",           en: "Cancelled",  color: "#dc2626", bg: "#fee2e2" },
};

const SAMPLE_PRODUCTS = [
  { name:"তাজা লাউ",    nameEn:"Fresh Gourd",  category:"vegetables", price:30, unit:"পিস",  farmer:"রহিম উদ্দিন", phone:"01711000001", upazila:"গাইবান্ধা সদর", qty:50,  image:"🥬", desc:"সরাসরি খামার থেকে তাজা লাউ" },
  { name:"দেশি আলু",    nameEn:"Local Potato", category:"vegetables", price:25, unit:"কেজি", farmer:"রহিম উদ্দিন", phone:"01711000001", upazila:"গোবিন্দগঞ্জ",   qty:200, image:"🥔", desc:"তাজা দেশি আলু, কোনো কেমিক্যাল নেই" },
  { name:"পাকা আম",     nameEn:"Ripe Mango",   category:"fruits",     price:80, unit:"কেজি", farmer:"রহিম উদ্দিন", phone:"01711000001", upazila:"সুন্দরগঞ্জ",    qty:100, image:"🥭", desc:"গাছ পাকা মিষ্টি আম" },
  { name:"মিনিকেট চাল", nameEn:"Miniket Rice", category:"grains",     price:65, unit:"কেজি", farmer:"রহিম উদ্দিন", phone:"01711000001", upazila:"সাঘাটা",         qty:500, image:"🌾", desc:"নতুন ফসলের সুগন্ধি মিনিকেট চাল" },
];

// ─── Main App ─────────────────────────────────────────────────
export default function App() {
  const [lang, setLang]         = useState("bn");
  const [view, setView]         = useState("home");
  const [products, setProducts] = useState([]);
  const [orders, setOrders]     = useState([]);
  const [selected, setSelected] = useState(null);
  const [cartItem, setCartItem] = useState(null);
  const [filterCat, setFilterCat] = useState("all");
  const [filterUp,  setFilterUp]  = useState("all");
  const [searchQ,   setSearchQ]   = useState("");
  const [toast, setToast]       = useState("");
  const [sellerIn, setSellerIn] = useState(false);
  const [loading, setLoading]   = useState(true);

  const t = (bn, en) => lang === "bn" ? bn : en;

  // ── Load products from Firebase (realtime) ──
  useEffect(() => {
    const q = query(collection(db, "products"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setProducts(data.length > 0 ? data : SAMPLE_PRODUCTS);
      setLoading(false);
    }, () => {
      setProducts(SAMPLE_PRODUCTS);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // ── Load orders from Firebase (realtime) ──
  useEffect(() => {
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    }, () => {});
    return () => unsub();
  }, []);

  const toast_ = (m) => { setToast(m); setTimeout(() => setToast(""), 2600); };

  const placeOrder = async (data) => {
    try {
      await addDoc(collection(db, "orders"), {
        ...data,
        status: "pending",
        createdAt: new Date().toISOString()
      });
      toast_(t("✅ অর্ডার সফল! বিক্রেতা শীঘ্রই যোগাযোগ করবেন।", "✅ Order placed! Seller will contact you soon."));
      setCartItem(null);
      setView("buyer");
    } catch (e) {
      toast_(t("❌ অর্ডার হয়নি, আবার চেষ্টা করুন","❌ Order failed, please try again"));
    }
  };

  const addProduct = async (data) => {
    try {
      await addDoc(collection(db, "products"), { ...data, createdAt: new Date().toISOString() });
      toast_(t("পণ্য যোগ হয়েছে ✓", "Product added ✓"));
    } catch {
      toast_(t("❌ সমস্যা হয়েছে", "❌ Something went wrong"));
    }
  };

  const deleteProduct = async (id) => {
    try {
      await deleteDoc(doc(db, "products", id));
      toast_(t("মুছে ফেলা হয়েছে", "Deleted"));
    } catch {}
  };

  const updateStatus = async (id, status) => {
    try {
      await updateDoc(doc(db, "orders", id), { status });
      toast_(t("অর্ডার আপডেট হয়েছে ✓", "Order updated ✓"));
    } catch {}
  };

  const filtered = products.filter(p => {
    const mc = filterCat === "all" || p.category === filterCat;
    const mu = filterUp  === "all" || p.upazila  === filterUp;
    const q  = searchQ.toLowerCase();
    const mq = !q || p.name.includes(q) || (p.nameEn||"").toLowerCase().includes(q) || (p.farmer||"").includes(q);
    return mc && mu && mq;
  });

  // ── Routing ──
  if (view === "home")    return <HomeView    lang={lang} setLang={setLang} t={t} setView={setView} pendingCount={orders.filter(o=>o.status==="pending").length} />;
  if (view === "product") return <ProductDetail p={selected} lang={lang} t={t} onBack={()=>setView("buyer")} onOrder={p=>{setCartItem(p);setView("order");}} />;
  if (view === "order")   return <OrderView   p={cartItem} lang={lang} t={t} onBack={()=>setView("buyer")} onConfirm={placeOrder} />;
  if (view === "seller")  return <SellerView  lang={lang} t={t} products={products} orders={orders} addProduct={addProduct} deleteProduct={deleteProduct} updateStatus={updateStatus} toast_={toast_} onBack={()=>setView("home")} sellerIn={sellerIn} setSellerIn={setSellerIn} />;

  // ── BUYER VIEW ──
  return (
    <div style={shell}>
      <TopBar lang={lang} setLang={setLang} t={t} onHome={()=>setView("home")} />
      <div style={{ flexShrink:0, padding:"12px 14px 0", background:"#f8fdf4" }}>
        <input value={searchQ} onChange={e=>setSearchQ(e.target.value)}
          placeholder={t("পণ্য খুঁজুন...","Search products...")} style={{...iSt,marginBottom:10}} />
        <div style={row}>
          <Chip active={filterCat==="all"} onClick={()=>setFilterCat("all")}>{t("সব","All")}</Chip>
          {CATEGORIES.map(c=><Chip key={c.id} active={filterCat===c.id} onClick={()=>setFilterCat(c.id)}>{c.icon} {t(c.bn,c.en)}</Chip>)}
        </div>
        <div style={{...row,paddingBottom:10}}>
          <Chip sm active={filterUp==="all"} onClick={()=>setFilterUp("all")}>{t("সব উপজেলা","All Upazila")}</Chip>
          {UPAZILAS.map(u=><Chip sm key={u} active={filterUp===u} onClick={()=>setFilterUp(u)}>{u}</Chip>)}
        </div>
      </div>
      <div style={{ flex:1, overflowY:"auto", padding:"0 14px 20px", background:"#f8fdf4" }}>
        {loading
          ? <div style={{ textAlign:"center", padding:"60px 0", color:"#6b7280" }}>⏳ {t("লোড হচ্ছে...","Loading...")}</div>
          : <>
            <div style={{ fontSize:12, color:"#6b7280", margin:"8px 0" }}>
              {filtered.length} {t("টি পণ্য · গাইবান্ধা জেলা","products · Gaibandha District")}
            </div>
            {filtered.length===0 && <Blank text={t("কোনো পণ্য পাওয়া যায়নি","No products found")} />}
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              {filtered.map(p=><PCard key={p.id} p={p} lang={lang} t={t} onClick={()=>{setSelected(p);setView("product");}} />)}
            </div>
          </>
        }
      </div>
      {toast && <ToastBar msg={toast} />}
    </div>
  );
}

// ── HOME ─────────────────────────────────────────────────────
function HomeView({ lang, setLang, t, setView, pendingCount }) {
  return (
    <div style={{ ...shell, background:"linear-gradient(160deg,#1a5c2a,#2d8a45,#52c46a)", color:"#fff" }}>
      <div style={{ padding:"20px 20px 0", display:"flex", justifyContent:"space-between" }}>
        <div style={{ fontSize:11, opacity:0.75 }}>🇧🇩 গাইবান্ধা জেলা, বাংলাদেশ</div>
        <LangBtn lang={lang} setLang={setLang} />
      </div>
      <div style={{ flex:1, display:"flex", flexDirection:"column", justifyContent:"center", padding:"16px 24px", textAlign:"center" }}>
        <div style={{ fontSize:64, marginBottom:6 }}>🌾</div>
        <div style={{ fontSize:28, fontWeight:800, lineHeight:1.1 }}>{t("গাইবান্ধা","Gaibandha")}</div>
        <div style={{ fontSize:18, fontWeight:600, opacity:0.9, marginBottom:4 }}>{t("কৃষি বাজার","Krishi Bazar")}</div>
        <div style={{ fontSize:12, opacity:0.65, marginBottom:32 }}>{t("সরাসরি কৃষকের কাছ থেকে তাজা পণ্য","Fresh products directly from farmer")}</div>
        <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
          <button onClick={()=>setView("buyer")} style={hBtn("#fff","#1a5c2a",false)}>
            <span style={{ fontSize:32 }}>🛒</span>
            <div style={{ textAlign:"left" }}>
              <div style={{ fontWeight:800, fontSize:17 }}>{t("পণ্য কিনুন","Buy Products")}</div>
              <div style={{ fontSize:12, opacity:0.65 }}>{t("তাজা সবজি, ফল, চাল দেখুন","Browse fresh vegetables, fruits, rice")}</div>
            </div>
          </button>
          <button onClick={()=>setView("seller")} style={hBtn("rgba(255,255,255,0.18)","#fff",true)}>
            <span style={{ fontSize:32 }}>👨‍🌾</span>
            <div style={{ textAlign:"left", flex:1 }}>
              <div style={{ fontWeight:800, fontSize:17 }}>{t("বিক্রেতা প্যানেল","Seller Panel")}</div>
              <div style={{ fontSize:12, opacity:0.65 }}>{t("পণ্য যোগ · অর্ডার · যোগাযোগ","Products · Orders · Contact")}</div>
            </div>
            {pendingCount>0 && <span style={{ background:"#ef4444", color:"#fff", borderRadius:50, minWidth:24, height:24, fontSize:12, fontWeight:800, display:"flex", alignItems:"center", justifyContent:"center", padding:"0 6px" }}>{pendingCount}</span>}
          </button>
        </div>
      </div>
      <div style={{ fontSize:11, textAlign:"center", opacity:0.45, paddingBottom:22 }}>📍 {t("শুধুমাত্র গাইবান্ধা জেলার জন্য","Only for Gaibandha District")}</div>
    </div>
  );
}

// ── PRODUCT DETAIL ───────────────────────────────────────────
function ProductDetail({ p, lang, t, onBack, onOrder }) {
  const cat = CATEGORIES.find(c=>c.id===p?.category);
  if (!p) return null;
  return (
    <div style={shell}>
      <GBar><BackBtn onClick={onBack}/><BTitle>{t("পণ্যের বিবরণ","Product Detail")}</BTitle></GBar>
      <div style={{ flex:1, overflowY:"auto" }}>
        <div style={{ background:"#f0faf0", padding:"36px", textAlign:"center", fontSize:80 }}>{p.image}</div>
        <div style={{ padding:"18px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:10 }}>
            <div style={{ fontSize:21, fontWeight:800, color:"#1a3c20", flex:1, marginRight:10 }}>{lang==="bn"?p.name:(p.nameEn||p.name)}</div>
            <div style={{ fontSize:20, fontWeight:800, color:"#2d8a45", whiteSpace:"nowrap" }}>৳{p.price}<span style={{ fontSize:12, color:"#6b7280", fontWeight:400 }}>/{p.unit}</span></div>
          </div>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:14 }}>
            <Pill bg="#dcfce7">{cat?.icon} {t(cat?.bn,cat?.en)}</Pill>
            <Pill bg="#dbeafe">📍 {p.upazila}</Pill>
            <Pill bg="#fef3c7">📦 {p.qty} {p.unit}</Pill>
          </div>
          <p style={{ fontSize:13, color:"#374151", lineHeight:1.7, marginBottom:18 }}>{p.desc}</p>
          <div style={{ background:"#f0faf0", borderRadius:14, padding:"14px", marginBottom:18, border:"1px solid #bbf7d0" }}>
            <div style={{ fontSize:11, color:"#6b7280", marginBottom:8 }}>👨‍🌾 {t("বিক্রেতার তথ্য","Seller Info")}</div>
            <div style={{ fontWeight:700, fontSize:16, color:"#1a3c20", marginBottom:10 }}>{p.farmer}</div>
            <div style={{ display:"flex", gap:8 }}>
              <a href={"tel:"+p.phone} style={cBtn("#1a5c2a","#fff")}>📞 {t("কল করুন","Call")}</a>
              <a href={"sms:"+p.phone} style={cBtn("#dcfce7","#1a5c2a")}>💬 SMS</a>
            </div>
            <div style={{ fontSize:11, color:"#6b7280", marginTop:8 }}>📞 {p.phone} · 📍 {p.upazila}</div>
          </div>
          <button onClick={()=>onOrder(p)} style={pBtn}>🛒 {t("অর্ডার করুন","Order Now")}</button>
        </div>
      </div>
    </div>
  );
}

// ── ORDER VIEW ───────────────────────────────────────────────
function OrderView({ p, lang, t, onBack, onConfirm }) {
  const [name,  setName]  = useState("");
  const [phone, setPhone] = useState("");
  const [addr,  setAddr]  = useState("");
  const [up,    setUp]    = useState("");
  const [qty,   setQty]   = useState(1);
  const [busy,  setBusy]  = useState(false);
  if (!p) return null;
  const total = qty * p.price;

  const submit = async () => {
    if (!name||!phone||!addr||!up) return alert(t("সব তথ্য পূরণ করুন","Fill all fields"));
    setBusy(true);
    await onConfirm({ productId:p.id||"", productName:p.name, productImage:p.image, productPrice:p.price, productUnit:p.unit, farmerName:p.farmer, farmerPhone:p.phone, farmerUpazila:p.upazila, customerName:name, customerPhone:phone, customerAddress:addr, customerUpazila:up, qty, total });
    setBusy(false);
  };

  return (
    <div style={shell}>
      <GBar><BackBtn onClick={onBack}/><BTitle>{t("অর্ডার করুন","Place Order")}</BTitle></GBar>
      <div style={{ flex:1, overflowY:"auto", padding:"16px" }}>
        <div style={{ background:"#f0faf0", borderRadius:13, padding:"11px", marginBottom:16, display:"flex", gap:11, alignItems:"center", border:"1px solid #bbf7d0" }}>
          <span style={{ fontSize:34 }}>{p.image}</span>
          <div>
            <div style={{ fontWeight:700 }}>{lang==="bn"?p.name:(p.nameEn||p.name)}</div>
            <div style={{ color:"#2d8a45", fontWeight:600 }}>৳{p.price}/{p.unit}</div>
            <div style={{ fontSize:11, color:"#6b7280" }}>👨‍🌾 {p.farmer} · {p.phone}</div>
          </div>
        </div>

        <Lbl t={t} bn="পরিমাণ" en="Quantity" />
        <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:14 }}>
          <QBtn onClick={()=>setQty(Math.max(1,qty-1))}>−</QBtn>
          <span style={{ fontWeight:700, fontSize:20, minWidth:28, textAlign:"center" }}>{qty}</span>
          <QBtn onClick={()=>setQty(qty+1)}>+</QBtn>
          <span style={{ fontSize:13, color:"#6b7280" }}>{p.unit}</span>
        </div>

        <Lbl t={t} bn="আপনার নাম *" en="Your Name *" />
        <input value={name} onChange={e=>setName(e.target.value)} placeholder={t("নাম লিখুন","Enter name")} style={{...iSt,marginBottom:10}} />
        <Lbl t={t} bn="মোবাইল নম্বর *" en="Mobile *" />
        <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="01XXXXXXXXX" type="tel" style={{...iSt,marginBottom:10}} />
        <Lbl t={t} bn="উপজেলা *" en="Upazila *" />
        <select value={up} onChange={e=>setUp(e.target.value)} style={{...iSt,marginBottom:10}}>
          <option value="">{t("বেছে নিন","Select")}</option>
          {UPAZILAS.map(u=><option key={u} value={u}>{u}</option>)}
        </select>
        <Lbl t={t} bn="পূর্ণ ঠিকানা *" en="Full Address *" />
        <textarea value={addr} onChange={e=>setAddr(e.target.value)} placeholder={t("গ্রাম, ইউনিয়ন...","Village, Union...")} style={{...iSt,height:68,resize:"none",marginBottom:16}} />

        <div style={{ background:"#1a5c2a", borderRadius:14, padding:"13px", marginBottom:16, color:"#fff" }}>
          <div style={{ display:"flex", justifyContent:"space-between", opacity:0.75, fontSize:13, marginBottom:4 }}>
            <span>{qty} × ৳{p.price}</span><span>৳{total}</span>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", fontWeight:800, fontSize:19 }}>
            <span>{t("মোট","Total")}</span><span>৳{total}</span>
          </div>
          <div style={{ fontSize:11, opacity:0.65, marginTop:5 }}>💵 {t("ক্যাশ অন ডেলিভারি","Cash on Delivery")}</div>
        </div>
        <button onClick={submit} disabled={busy} style={{ ...pBtn, opacity:busy?0.7:1 }}>
          {busy ? t("⏳ অপেক্ষা করুন...","⏳ Please wait...") : `✅ ${t("অর্ডার নিশ্চিত করুন","Confirm Order")}`}
        </button>
      </div>
    </div>
  );
}

// ── SELLER VIEW ──────────────────────────────────────────────
function SellerView({ lang, t, products, orders, addProduct, deleteProduct, updateStatus, toast_, onBack, sellerIn, setSellerIn }) {
  const [passInput, setPassInput] = useState("");
  const [tab,  setTab]       = useState("orders");
  const [filterSt, setFilterSt] = useState("all");

  const [img,   setImg]   = useState("🌿");
  const [nm,    setNm]    = useState("");
  const [nmEn,  setNmEn]  = useState("");
  const [cat,   setCat]   = useState("");
  const [price, setPrice] = useState("");
  const [unit,  setUnit]  = useState("কেজি");
  const [qty,   setQty_]  = useState("");
  const [fnm,   setFnm]   = useState("");
  const [ph,    setPh]    = useState("");
  const [up,    setUp]    = useState("");
  const [desc,  setDesc]  = useState("");
  const [busy,  setBusy]  = useState(false);

  const EMOJIS = ["🥬","🥕","🍅","🌽","🥔","🧅","🧄","🍋","🥭","🍌","🍎","🌾","🐟","🥚","🌶️","🫚","🌿","🧆"];
  const pendingOrders  = orders.filter(o=>o.status==="pending");
  const filteredOrders = filterSt==="all" ? orders : orders.filter(o=>o.status===filterSt);

  const handleAdd = async () => {
    if (!nm||!cat||!price||!fnm||!ph||!up) { alert(t("* চিহ্নিত তথ্য পূরণ করুন","Fill required fields")); return; }
    setBusy(true);
    await addProduct({ name:nm, nameEn:nmEn, category:cat, price:Number(price), unit, qty:Number(qty)||0, farmer:fnm, phone:ph.replace(/-/g,""), upazila:up, desc, image:img });
    setBusy(false);
    setNm(""); setNmEn(""); setCat(""); setPrice(""); setQty_(""); setDesc("");
  };

  // LOGIN
  if (!sellerIn) return (
    <div style={shell}>
      <GBar><BackBtn onClick={onBack}/><BTitle>👨‍🌾 {t("বিক্রেতা প্যানেল","Seller Panel")}</BTitle></GBar>
      <div style={{ flex:1, display:"flex", flexDirection:"column", justifyContent:"center", padding:"30px 26px" }}>
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ fontSize:60, marginBottom:8 }}>🔐</div>
          <div style={{ fontSize:18, fontWeight:700, color:"#1a3c20" }}>{t("পাসওয়ার্ড দিয়ে প্রবেশ করুন","Enter seller password")}</div>
          <div style={{ fontSize:12, color:"#6b7280", marginTop:6 }}>{t("শুধুমাত্র বিক্রেতার জন্য","For seller only")}</div>
        </div>
        <Lbl t={t} bn="পাসওয়ার্ড" en="Password" />
        <input type="password" value={passInput} onChange={e=>setPassInput(e.target.value)}
          onKeyDown={e=>e.key==="Enter"&&(passInput===SELLER_PASS?setSellerIn(true):alert(t("ভুল পাসওয়ার্ড","Wrong password")))}
          placeholder="••••••••" style={{...iSt,marginBottom:14,fontSize:18,textAlign:"center",letterSpacing:4}} />
        <button onClick={()=>{ if(passInput===SELLER_PASS) setSellerIn(true); else alert(t("ভুল পাসওয়ার্ড","Wrong password")); }} style={pBtn}>
          🔓 {t("প্রবেশ করুন","Login")}
        </button>
        <div style={{ fontSize:11, color:"#9ca3af", textAlign:"center", marginTop:10 }}>{t("পাসওয়ার্ড: krishi2026","Password: krishi2026")}</div>
      </div>
    </div>
  );

  return (
    <div style={shell}>
      <div style={{ background:"#1a5c2a", padding:"12px 16px", display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <BackBtn onClick={onBack}/>
          <div>
            <div style={{ color:"#fff", fontWeight:800, fontSize:15 }}>👨‍🌾 {t("বিক্রেতা প্যানেল","Seller Panel")}</div>
            <div style={{ color:"#86efac", fontSize:10 }}>{t("গাইবান্ধা কৃষি বাজার","Gaibandha Krishi Bazar")}</div>
          </div>
        </div>
        <button onClick={()=>setSellerIn(false)} style={{ background:"rgba(255,255,255,0.15)", border:"none", color:"#fff", borderRadius:8, padding:"5px 11px", cursor:"pointer", fontSize:12 }}>{t("লগআউট","Logout")}</button>
      </div>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", background:"#fff", borderBottom:"1px solid #e5e7eb", flexShrink:0 }}>
        {[
          { label:t("পণ্য","Products"),  val:products.length, color:"#1a5c2a" },
          { label:t("মোট","Total"),      val:orders.length,   color:"#6b7280" },
          { label:t("নতুন","New"),       val:pendingOrders.length, color:"#f59e0b" },
          { label:t("ডেলিভারি","Done"), val:orders.filter(o=>o.status==="delivered").length, color:"#1d4ed8" },
        ].map(s=>(
          <div key={s.label} style={{ textAlign:"center", padding:"10px 4px" }}>
            <div style={{ fontWeight:800, fontSize:20, color:s.color }}>{s.val}</div>
            <div style={{ fontSize:10, color:"#9ca3af" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display:"flex", background:"#fff", borderBottom:"2px solid #e5e7eb", flexShrink:0 }}>
        {[
          { id:"orders",   bn:"📦 অর্ডার",     en:"📦 Orders",   badge:pendingOrders.length },
          { id:"products", bn:"🌿 পণ্য তালিকা", en:"🌿 Products" },
          { id:"add",      bn:"➕ পণ্য যোগ",    en:"➕ Add" },
        ].map(tb=>(
          <button key={tb.id} onClick={()=>setTab(tb.id)} style={{ flex:1, padding:"11px 2px", border:"none", background:"none", cursor:"pointer", fontWeight:tab===tb.id?700:400, color:tab===tb.id?"#1a5c2a":"#6b7280", borderBottom:tab===tb.id?"3px solid #1a5c2a":"3px solid transparent", fontSize:12 }}>
            {t(tb.bn,tb.en)}
            {(tb.badge||0)>0 && <span style={{ background:"#ef4444", color:"#fff", borderRadius:50, fontSize:9, fontWeight:800, padding:"1px 5px", marginLeft:3 }}>{tb.badge}</span>}
          </button>
        ))}
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"14px", background:"#f8fdf4" }}>

        {/* ORDERS */}
        {tab==="orders" && (
          <div>
            <div style={{...row,marginBottom:10}}>
              {["all","pending","confirmed","delivered","cancelled"].map(s=>(
                <Chip sm key={s} active={filterSt===s} onClick={()=>setFilterSt(s)}>
                  {s==="all"?t("সব","All"):t(STATUS[s].bn,STATUS[s].en)}
                </Chip>
              ))}
            </div>
            {filteredOrders.length===0 && <Blank text={t("কোনো অর্ডার নেই","No orders yet")} />}
            {filteredOrders.map(o=><OCard key={o.id} o={o} t={t} onUpdate={updateStatus} />)}
          </div>
        )}

        {/* PRODUCTS LIST */}
        {tab==="products" && (
          <div>
            {products.length===0 && <Blank text={t("কোনো পণ্য নেই","No products")} />}
            {products.map(p=>(
              <div key={p.id} style={{ background:"#fff", borderRadius:14, padding:"12px", marginBottom:10, display:"flex", gap:10, alignItems:"center", border:"1px solid #e5e7eb" }}>
                <span style={{ fontSize:30 }}>{p.image}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:13 }}>{p.name}</div>
                  <div style={{ color:"#2d8a45", fontWeight:600, fontSize:13 }}>৳{p.price}/{p.unit} · {p.qty} {p.unit}</div>
                  <div style={{ fontSize:11, color:"#6b7280" }}>📍 {p.upazila}</div>
                </div>
                <button onClick={()=>{ if(window.confirm(t("মুছবেন?","Delete?"))) deleteProduct(p.id); }} style={{ background:"#fee2e2", border:"none", color:"#dc2626", borderRadius:8, padding:"6px 11px", cursor:"pointer", fontWeight:600, fontSize:12 }}>{t("মুছুন","Del")}</button>
              </div>
            ))}
          </div>
        )}

        {/* ADD PRODUCT */}
        {tab==="add" && (
          <div style={{ display:"flex", flexDirection:"column", gap:11 }}>
            <div>
              <Lbl t={t} bn="ইমোজি" en="Emoji" />
              <div style={{ display:"flex", flexWrap:"wrap", gap:6 }}>
                {EMOJIS.map(e=><button key={e} onClick={()=>setImg(e)} style={{ fontSize:22, background:img===e?"#dcfce7":"#fff", border:img===e?"2px solid #2d8a45":"1px solid #e5e7eb", borderRadius:8, padding:"3px 7px", cursor:"pointer" }}>{e}</button>)}
              </div>
            </div>
            <div><Lbl t={t} bn="পণ্যের নাম (বাংলা) *" en="Name (Bangla) *" /><input value={nm} onChange={e=>setNm(e.target.value)} placeholder={t("যেমন: তাজা লাউ","e.g. Fresh Gourd")} style={iSt} /></div>
            <div><Lbl t={t} bn="পণ্যের নাম (English)" en="Name (English)" /><input value={nmEn} onChange={e=>setNmEn(e.target.value)} placeholder="e.g. Fresh Gourd" style={iSt} /></div>
            <div><Lbl t={t} bn="বিক্রেতার নাম *" en="Seller Name *" /><input value={fnm} onChange={e=>setFnm(e.target.value)} placeholder={t("আপনার নাম","Your name")} style={iSt} /></div>
            <div><Lbl t={t} bn="মোবাইল নম্বর *" en="Mobile *" /><input value={ph} onChange={e=>setPh(e.target.value)} placeholder="01XXXXXXXXX" type="tel" style={iSt} /></div>
            <div>
              <Lbl t={t} bn="বিভাগ *" en="Category *" />
              <select value={cat} onChange={e=>setCat(e.target.value)} style={iSt}>
                <option value="">{t("বেছে নিন","Select")}</option>
                {CATEGORIES.map(c=><option key={c.id} value={c.id}>{c.icon} {t(c.bn,c.en)}</option>)}
              </select>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
              <div><Lbl t={t} bn="দাম (৳) *" en="Price *" /><input value={price} onChange={e=>setPrice(e.target.value)} type="number" placeholder="0" style={iSt} /></div>
              <div>
                <Lbl t={t} bn="একক" en="Unit" />
                <select value={unit} onChange={e=>setUnit(e.target.value)} style={iSt}>
                  {["কেজি","গ্রাম","লিটার","পিস","ডজন","মণ","বান্ডিল"].map(u=><option key={u} value={u}>{u}</option>)}
                </select>
              </div>
            </div>
            <div><Lbl t={t} bn="পরিমাণ (মজুদ)" en="Stock Qty" /><input value={qty} onChange={e=>setQty_(e.target.value)} type="number" placeholder="0" style={iSt} /></div>
            <div>
              <Lbl t={t} bn="উপজেলা *" en="Upazila *" />
              <select value={up} onChange={e=>setUp(e.target.value)} style={iSt}>
                <option value="">{t("বেছে নিন","Select")}</option>
                {UPAZILAS.map(u=><option key={u} value={u}>{u}</option>)}
              </select>
            </div>
            <div><Lbl t={t} bn="বিবরণ" en="Description" /><textarea value={desc} onChange={e=>setDesc(e.target.value)} placeholder={t("পণ্য সম্পর্কে লিখুন...","About the product...")} style={{...iSt,height:68,resize:"none"}} /></div>
            <button onClick={handleAdd} disabled={busy} style={{ ...pBtn, opacity:busy?0.7:1 }}>
              {busy ? t("⏳ যোগ হচ্ছে...","⏳ Adding...") : `➕ ${t("পণ্য যোগ করুন","Add Product")}`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── ORDER CARD ───────────────────────────────────────────────
function OCard({ o, t, onUpdate }) {
  const [open, setOpen] = useState(false);
  const st   = STATUS[o.status] || STATUS.pending;
  const date = new Date(o.createdAt).toLocaleDateString("bn-BD",{day:"numeric",month:"short"});

  return (
    <div style={{ background:"#fff", borderRadius:14, marginBottom:10, overflow:"hidden", border:"1px solid #e5e7eb", borderLeft:`4px solid ${st.color}` }}>
      <div onClick={()=>setOpen(!open)} style={{ padding:"12px 14px", cursor:"pointer", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, flex:1 }}>
          <span style={{ fontSize:26 }}>{o.productImage}</span>
          <div>
            <div style={{ fontWeight:700, fontSize:13 }}>{o.customerName}</div>
            <div style={{ fontSize:11, color:"#6b7280" }}>{o.productName} · {o.qty} {o.productUnit} · ৳{o.total}</div>
            <div style={{ fontSize:10, color:"#9ca3af" }}>{date}</div>
          </div>
        </div>
        <div style={{ display:"flex", flexDirection:"column", alignItems:"flex-end", gap:5 }}>
          <span style={{ background:st.bg, color:st.color, borderRadius:20, padding:"3px 9px", fontSize:10, fontWeight:700 }}>{t(st.bn,st.en)}</span>
          <span style={{ fontSize:11, color:"#d1d5db" }}>{open?"▲":"▼"}</span>
        </div>
      </div>

      {open && (
        <div style={{ padding:"0 14px 14px", borderTop:"1px solid #f3f4f6" }}>
          <div style={{ background:"#f8fdf4", borderRadius:10, padding:"11px", marginBottom:10, border:"1px solid #dcfce7" }}>
            <div style={{ fontSize:11, color:"#6b7280", marginBottom:6 }}>🧑 {t("ক্রেতার তথ্য","Buyer Info")}</div>
            <div style={{ fontWeight:700, fontSize:15, color:"#1a3c20" }}>{o.customerName}</div>
            <div style={{ fontSize:12, color:"#374151", marginTop:3 }}>📍 {o.customerAddress}, {o.customerUpazila}</div>
            <div style={{ display:"flex", gap:8, marginTop:10 }}>
              <a href={"tel:"+o.customerPhone} style={{ ...cBtn("#1a5c2a","#fff"), flex:1, justifyContent:"center", textDecoration:"none" }}>📞 {t("কল করুন","Call")}</a>
              <a href={`sms:${o.customerPhone}?body=${encodeURIComponent("আপনার অর্ডার পেয়েছি। শীঘ্রই ডেলিভারি দেওয়া হবে।")}`} style={{ ...cBtn("#dcfce7","#1a5c2a"), flex:1, justifyContent:"center", textDecoration:"none" }}>💬 SMS</a>
            </div>
            <div style={{ fontSize:11, color:"#6b7280", marginTop:6 }}>📞 {o.customerPhone}</div>
          </div>
          <div style={{ background:"#f9fafb", borderRadius:10, padding:"10px", marginBottom:10, fontSize:12 }}>
            {[[t("পণ্য","Product"),o.productName],[t("পরিমাণ","Qty"),`${o.qty} ${o.productUnit}`],[t("একক মূল্য","Unit price"),`৳${o.productPrice}`]].map(([l,v])=>(
              <div key={l} style={{ display:"flex", justifyContent:"space-between", marginBottom:3 }}>
                <span style={{ color:"#6b7280" }}>{l}</span><span style={{ fontWeight:600 }}>{v}</span>
              </div>
            ))}
            <div style={{ display:"flex", justifyContent:"space-between", borderTop:"1px solid #e5e7eb", paddingTop:6, marginTop:4 }}>
              <span style={{ fontWeight:700 }}>{t("মোট","Total")}</span>
              <span style={{ fontWeight:800, color:"#1a5c2a", fontSize:15 }}>৳{o.total}</span>
            </div>
          </div>
          {o.status!=="delivered" && o.status!=="cancelled" && (
            <div style={{ display:"flex", gap:8 }}>
              {o.status==="pending"   && <button onClick={()=>onUpdate(o.id,"confirmed")} style={{...aBtn,background:"#dcfce7",color:"#1a5c2a"}}>✅ {t("নিশ্চিত করুন","Confirm")}</button>}
              {o.status==="confirmed" && <button onClick={()=>onUpdate(o.id,"delivered")} style={{...aBtn,background:"#dbeafe",color:"#1d4ed8"}}>🚚 {t("ডেলিভারি হয়েছে","Delivered")}</button>}
              <button onClick={()=>onUpdate(o.id,"cancelled")} style={{...aBtn,background:"#fee2e2",color:"#dc2626"}}>✕ {t("বাতিল","Cancel")}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Reusable Components ──────────────────────────────────────
function TopBar({ lang, setLang, t, onHome }) {
  return (
    <div style={{ background:"#1a5c2a", padding:"12px 16px", display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
      <button onClick={onHome} style={{ background:"none", border:"none", color:"#fff", cursor:"pointer", fontSize:24 }}>🌾</button>
      <div style={{ textAlign:"center" }}>
        <div style={{ color:"#fff", fontWeight:800, fontSize:15 }}>{t("গাইবান্ধা কৃষি বাজার","Gaibandha Krishi Bazar")}</div>
        <div style={{ color:"#86efac", fontSize:10 }}>📍 {t("গাইবান্ধা জেলা","Gaibandha District")}</div>
      </div>
      <LangBtn lang={lang} setLang={setLang} />
    </div>
  );
}

function GBar({ children }) { return <div style={{ background:"#1a5c2a", padding:"13px 16px", display:"flex", alignItems:"center", gap:12, flexShrink:0 }}>{children}</div>; }
function BTitle({ children }) { return <span style={{ color:"#fff", fontWeight:700, fontSize:15 }}>{children}</span>; }
function BackBtn({ onClick }) { return <button onClick={onClick} style={{ background:"rgba(255,255,255,0.18)", border:"none", color:"#fff", borderRadius:8, padding:"6px 12px", cursor:"pointer", fontSize:16 }}>←</button>; }
function LangBtn({ lang, setLang }) { return <button onClick={()=>setLang(lang==="bn"?"en":"bn")} style={{ background:"rgba(255,255,255,0.18)", border:"1px solid rgba(255,255,255,0.3)", color:"#fff", borderRadius:20, padding:"4px 12px", cursor:"pointer", fontSize:12, fontWeight:600 }}>{lang==="bn"?"EN":"বাং"}</button>; }
function Chip({ children, active, onClick, sm }) { return <button onClick={onClick} style={{ flexShrink:0, padding:sm?"5px 10px":"6px 14px", borderRadius:50, border:"none", cursor:"pointer", fontSize:sm?11:12, fontWeight:active?700:500, background:active?"#1a5c2a":"#fff", color:active?"#fff":"#374151", boxShadow:active?"0 2px 8px rgba(26,92,42,0.3)":"0 1px 3px rgba(0,0,0,0.08)" }}>{children}</button>; }
function Pill({ bg, children }) { return <span style={{ background:bg, borderRadius:20, padding:"3px 10px", fontSize:11, fontWeight:600 }}>{children}</span>; }
function Lbl({ t, bn, en }) { return <div style={{ fontSize:12, fontWeight:600, color:"#374151", marginBottom:5 }}>{t(bn,en)}</div>; }
function QBtn({ children, onClick }) { return <button onClick={onClick} style={{ background:"#f0faf0", border:"1px solid #bbf7d0", borderRadius:8, width:36, height:36, fontSize:20, cursor:"pointer", fontWeight:700, color:"#1a5c2a" }}>{children}</button>; }
function PCard({ p, lang, onClick }) { return <div onClick={onClick} style={{ background:"#fff", borderRadius:16, overflow:"hidden", cursor:"pointer", boxShadow:"0 2px 8px rgba(0,0,0,0.06)", border:"1px solid #e5e7eb" }}><div style={{ background:"#f0faf0", padding:"18px 0", textAlign:"center", fontSize:46 }}>{p.image}</div><div style={{ padding:"10px 10px 12px" }}><div style={{ fontWeight:700, fontSize:13, color:"#1a3c20", lineHeight:1.3 }}>{lang==="bn"?p.name:(p.nameEn||p.name)}</div><div style={{ color:"#2d8a45", fontWeight:800, fontSize:16 }}>৳{p.price}<span style={{ fontSize:11, color:"#6b7280", fontWeight:400 }}>/{p.unit}</span></div><div style={{ fontSize:11, color:"#9ca3af", marginTop:3 }}>📍 {p.upazila}</div><div style={{ fontSize:11, color:"#9ca3af" }}>👨‍🌾 {p.farmer}</div></div></div>; }
function Blank({ text }) { return <div style={{ textAlign:"center", color:"#9ca3af", padding:"40px 0", fontSize:13 }}>{text}</div>; }
function ToastBar({ msg }) { return <div style={{ position:"fixed", bottom:24, left:"50%", transform:"translateX(-50%)", background:"#1a5c2a", color:"#fff", padding:"10px 22px", borderRadius:50, fontSize:13, fontWeight:600, zIndex:999, boxShadow:"0 4px 20px rgba(26,92,42,0.4)", whiteSpace:"nowrap" }}>{msg}</div>; }

// ── Styles ───────────────────────────────────────────────────
const shell = { display:"flex", flexDirection:"column", height:"100vh", fontFamily:"'Segoe UI','Noto Sans Bengali',sans-serif", background:"#f8fdf4", overflow:"hidden" };
const iSt   = { width:"100%", padding:"10px 13px", borderRadius:10, border:"1px solid #d1fae5", fontSize:14, outline:"none", boxSizing:"border-box", background:"#fff", color:"#111" };
const pBtn  = { width:"100%", padding:"13px", background:"linear-gradient(135deg,#1a5c2a,#2d8a45)", color:"#fff", border:"none", borderRadius:14, fontSize:15, fontWeight:700, cursor:"pointer" };
const row   = { display:"flex", gap:8, overflowX:"auto", paddingBottom:6, scrollbarWidth:"none" };
const aBtn  = { flex:1, padding:"9px 10px", border:"none", borderRadius:10, fontSize:13, fontWeight:600, cursor:"pointer" };
const cBtn  = (bg, color) => ({ display:"flex", alignItems:"center", gap:5, padding:"9px 14px", borderRadius:10, fontSize:13, fontWeight:600, cursor:"pointer", background:bg, color });
const hBtn  = (bg, color, brd) => ({ display:"flex", alignItems:"center", gap:16, background:bg, color, border:brd?"1px solid rgba(255,255,255,0.25)":"none", borderRadius:16, padding:"16px 18px", cursor:"pointer", textAlign:"left", width:"100%" });
